<form action="" method="POST">
	<input type="text" name="angka">
	<br/>
	<input type="submit" name="hasil" value="ENCRIPSI">
	<input type="reset" name="desc" value="CANCEL">
</form>
<?php 
 
	if (isset($_POST["hasil"])){
		$angka = md5($_POST["angka"]);
		echo $angka;
	}
 
 ?>
